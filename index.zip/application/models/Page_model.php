<?php if (!defined('BASEPATH')) 	exit('Hacking Attempt : Get Out of the system ..!');

class Page_model extends CI_Model {
	
//	public function contact () {
//		return $this->db->select('*')->from('contact')->get()->row();
//	}
	
	/* function get_all_news($start, $per_page)
	  {
	  $query = $this->db->query("SELECT * FROM tbl_news WHERE category_id='CAT000003' ORDER BY id DESC LIMIT ".$start.", ".$per_page." ");
	  return $query->result();
	  }

	  function count_news_by_category($category=NULL)
	  {
	  $query = $this->db->query("SELECT * FROM tbl_news WHERE category_id='CAT000003' ");
	  return $query->num_rows();
	  } */
}
