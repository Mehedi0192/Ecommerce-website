<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/bamboo-2.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Bamboo Products</h3>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo/j-1.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
            <a href="#" target="_blank"> <img src="images/product/bamboo//j-2.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-3.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-4.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-5.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-6.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-1.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/bamboo//j-2.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Bamboo Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
    </div>
    
</section>

<?php include('inc/footer.php');?>