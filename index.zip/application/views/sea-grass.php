<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/sea-grass-1.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Sea Grass Products</h3>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-1.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-2.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-3.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-4.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-5.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-6.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-7.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/sea-grass/s-8.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Sea Grass Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="btn-toolbar demoPadder" role="toolbar" aria-label="Toolbar with button groups">
            <div class="btn-group" role="group" aria-label="First group">
                <a type="button" class="btn btn-default" href="sea-grass.php">1</a>
                <a type="button" class="btn btn-default" href="sea-grass-pages-2.php">2</a>
            </div>
        </div> 
    </div>
    
</section>

<?php include('inc/footer.php');?>