<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/cane-2.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Tote Bags</h3>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-1.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
            <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-2.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-3.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-4.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-5.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-6.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-7.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/tote/t-8.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Tote Bags</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
    </div>
    
</section>

<?php include('inc/footer.php');?>