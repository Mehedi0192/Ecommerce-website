<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/wood-2.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Wood Products</h3>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-1.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
            <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-2.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-3.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-4.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-5.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-6.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-7.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/wood/j-8.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Wood Products</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
    </div>
</section>

<?php include('inc/footer.php');?>