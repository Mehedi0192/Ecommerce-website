<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/nokshi-1.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Nokshi katha</h3>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-1.jpg"  class="img-responsive"> </a>
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
            <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-2.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-3.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-4.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;8.95</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-5.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;8.95</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-6.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-7.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/nokshi-katha/j-8.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Nokshi katha</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
    </div>
</section>

<?php include('inc/footer.php');?>