<?php include('inc/header.php');?>

<section class="inr-banner">
    	<div class="innr-slid">
        	<img src="images/inn-bnr/jwle-2.jpg">
        </div>
</section>

<section class="about-pages-area">
    
    <div class="container">
    <h3>Jute Products</h3>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-6.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-7.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-8.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/jwle/d-9.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-10.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="#" target="_blank"> <img src="images/product/jwle/d-11.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="#" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-12.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-13.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-14.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-15.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-3 col-xs-12 column productbox">
           <a href="product-details.php" target="_blank"> <img src="images/product/jwle/d-16.jpg"  class="img-responsive"> </a> 
        <div class="producttitle">Jute Product</div>
            <div class="productprice">
                <div class="pull-right">
                    <a href="product-details.php" class="btn btn-danger btn-sm" role="button">Details</a>
                </div>
                <div class="pricetext">$&nbsp;</div>
            </div>
        </div>
        <div class="btn-toolbar demoPadder" role="toolbar" aria-label="Toolbar with button groups">
            <div class="btn-group" role="group" aria-label="First group">
                <a type="button" class="btn btn-default" href="jwle.php">1</a>
                <a type="button" class="btn btn-default" href="jwle-pages-2.php">2</a>
            </div>
        </div>     

    </div>
    
</section>

<?php include('inc/footer.php');?>